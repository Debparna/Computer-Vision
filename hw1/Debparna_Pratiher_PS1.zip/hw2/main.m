i = imread('inputSeamCarvingPrague.jpg');
j = imread('inputSeamCarvingMall.jpg');

figure;
imshow(i);
energyImage = energy_image(i);
cumulativeEnergyMap1 = cumulative_minimum_energy_map(energyImage, 'HORIZONTAL');
cumulativeEnergyMap2 = cumulative_minimum_energy_map(energyImage, 'VERTICAL');

horizontalSeam = find_optimal_horizontal_seam(cumulativeEnergyMap1);
verticalSeam = find_optimal_vertical_seam(cumulativeEnergyMap2);

figure;
display_seam(i, horizontalSeam, 'HORIZONTAL');
figure;
display_seam(i, verticalSeam, 'VERTICAL');


%[reducedColorImage, reducedEnergyImage] = reduce_width(i, energyImage);
%[reducedColorImage, reducedEnergyImage] = reduce_height(i, energyImage);



